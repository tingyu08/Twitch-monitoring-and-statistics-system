# Twitch Analytics 個人資料匯出

本壓縮包包含您在 Twitch Analytics 平台上的所有個人資料。

## 檔案說明

### json/ 目錄
- profile.json - 您的基本資料
- watch-time-stats.json - 觀看時數記錄
- message-stats.json - 留言與互動統計
- lifetime-stats.json - 全時段統計聚合
- privacy-settings.json - 您的隱私設定

### csv/ 目錄
- watch-time-daily.csv - 每日觀看時數（可用 Excel 開啟）
- messages-daily.csv - 每日留言統計（可用 Excel 開啟）

## 資料使用說明

這些資料是根據 GDPR 及相關隱私法規的「資料可攜權」條款提供給您的。
您可以自由使用這些資料，或將其匯入其他服務。

## 問題回報

如有任何問題，請聯繫我們的支援團隊。

匯出時間: 2025-12-17T07:48:28.790Z
